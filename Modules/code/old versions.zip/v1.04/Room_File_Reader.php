<?php
//******************************************************************************
//    James Reatherford
//    Hongbin Yu
//******************************************************************************
//    Created on: 4/12/13
//    Last Edit on: 4/12/13
//******************************************************************************
//    Things missing in this version:
//      *does not produces real error codes
//      *Documentation needs improvement
//      *Needs to be tested to make sure it conforms to coding standards
//******************************************************************************
class File_Reader1
{
    
    // $text
    protected $file_name;
    protected $data_list;
    protected $error_list;
    
     public function __construct($file_to_check)
    {
        //$this->text = preg_replace("/\h/"," ",$file_text);
        $this->file_name = $file_to_check;
        $data_list = array();
        $error_list = array();
    }
    
    public function Scan_File (){}
    
    function Skip_Whitespace(&$next_pos, $buffer)
    {
        //skip past whitespace at the start
        while ($buffer[$next_pos] != "\n" && ($buffer[$next_pos] == ' '))
            $next_pos++;
    }
    
    protected function Grab_Field(&$next_pos, $buffer, $delimiter)
    {   
        $this->Skip_Whitespace($next_pos, $buffer);
        $current_pos = $next_pos;
        
        //skip over the word until the next whitespace
        while ($buffer[$next_pos] != "\n" && $buffer[$next_pos] != $delimiter)
            $next_pos++;
        
        // no token can be read
        if ($next_pos == $current_pos){
            return false;
        }
        // return token to be validated
        else{
            return trim(substr($buffer, $current_pos, ($next_pos - $current_pos)));
        }
    }
    

}


 class Room_File_Reader extends File_Reader1
 {
    //**************************************************************************
    //    SCAN_FILE
    //    
    //    James Reatherford, Hongbin Yu
    //**************************************************************************
    //    This function scans through the text it was given at creation,
    //    picks apart the fields and creates a list of abailable time objects.
    //    
    //    The function also keeps track of all errors found while scanning.
    //    
    //    If any errors were found, the function returns a list of them.  
    //    Otherwise it returns the list of available rooms.
    //**************************************************************************
     
     
     
     Public Function Scan_File()
     {
         $line_number = 0;
         $text = @fopen("tests//".$this->file_name, "r");
         if ($text)
         {
             while ($buffer = fgets($text))
             {
                 echo "------------------------------------<br>";
                 $this->Read_A_Line($buffer, $line_number);
                 $line_number++;
                 echo " ------------------------------------<br>";
             }
             if (!feof($text)) {
                 echo "Error: unexpected fgets() fail\n";
             }
             fclose($text);
          
         }
         else
         {
             //optional 
             //$file = fopen("testFile.txt", "r") or exit("Unable to open file!");
             $this->error_list[] = "Couldn't Open file $this->file_name<br>";
         }
     }
     
     
     Public Function Read_A_Line($buffer, $line_number)
     {
         //$current_pos = 0;
         $next_pos = 0;
         $error_found;
         $next_token;
         
         // check if it is empty line
         if ($buffer[0] == "\n")
         {
             $this->error_list[] = "$error_table[13] at line $line_number<br>";
         }
         else
         {   
             // read the room type
             //$next_token = $this->Grab_Field($next_pos, $buffer, " ");
             if ($next_token = $this->Grab_Field($next_pos, $buffer, " "))
             {
                 // room type recognizer
                 $error_found = Room_Type_Recognizer::read($next_token);
                 if ($error_found == false)
                     echo "$next_token <br>";
                 else
                     $this->error_list[] = "$error_table[$error_found] at line $line_number<br>";
             }
             else
                 $this->error_list[] = "$error_table[19] at line $line_number<br>";
             
            
            // read the room size
            if ($next_token = $this->Grab_Field($next_pos, $buffer, " "))
             {
                 // room type recognizer
                 $error_found = Room_Size_Recognizer::read($next_token);
                 if ($error_found == false)
                     echo "$next_token <br>";
                 else
                     $this->error_list[] = "$error_table[$error_found] at line $line_number<br>";
             }
             else
                 $this->error_list[] = "$error_table[15] at line $line_number<br>";
             
            // read the room 
            //$room_name = $$this->Grab_Field($next_pos, $buffer, " ");
            //$room_number = $this->Grab_Field($next_pos, $buffer, " ");
            
            if ($room_name = $$this->Grab_Field($next_pos, $buffer, " ") == false)
                $this->error_list[] = "$error_table[20] at line $line_number<br>";
            
            else if (ctype_digit($buffer[++$next_pos])){
                if ($room_number = $this->Grab_Field($next_pos, $buffer, " "))
                        // do your thing
                
                    
            }
            else
                $this->error_list[] = "$error_table[8] at line $line_number<br>";
                ($room_number = $this->Grab_Field($next_pos, $buffer, "\n"))
            // skip spaces (function here)
            // update current, read till next space and one more to 
            // get the whole thing of the room format
            // then call room recognizer
         }
         
            
     }
     
     
     Public Function Scan_File1()
     {
         $errors = array();
         $times = array();
         $day_time_patterns = array();
         $lines = explode("\n", $this->text);
         $curr_line;
         $curr_field;
         $current_time;
         $line = 1;
         
         foreach ($lines as $curr_line)
         {
             $cursor = 0;
             
             //get duration field
             $this->Skip_Whitespace($cursor, $curr_line);
             $curr_field = $this->Grab_Field($cursor, $curr_line); ///make sure does not inlcude - and decimal numbers
             //ERROR CHECK: MISSING OR INCORRECT DURATION FIELD
             if (is_numeric($curr_field) == false)
                 $errors[] = $line;
             else
             {
                 $current_time = new Class_Time();
                 $current_time->duration = $curr_field;
             }
             
             //get days field
             $curr_field = Days_Recognizer::read($curr_line,$cursor,$line);
             //ERROR CHECK: MISSING OR INCORRECT DURATION FIELD
             if (is_numeric($curr_field) == true)
                 $errors[] = $line;//$curr_field;
             else
             {
                 $current_time->days = $curr_field;
                 $curr_pattern = "$current_time->duration $current_time->days";
                 //ERROR CHECK: DUPLICATE DAY/TIME COMBINATIONS
                 if (in_array($curr_pattern,$day_time_patterns))
                     $errors[] = $line;
                 //ERROR CHECK: WHITESPACE AFTER THE DAYS FIELD
                 else if ($curr_line[$cursor] == " ")
                     $errors[] = $line;
                 else
                     $day_time_patterns[] = $curr_pattern;
             }

             //get start times
            //ERROR CHECK: NO TIMES LISTED ON LINE
            if ($cursor > (strlen($curr_line)-4))
                $errors[] = $line;
            while ($cursor <= (strlen($curr_line)-4))
            {
                 $curr_field = Time_Recognizer::read($curr_line,$cursor,$line);
                 //ERROR CHECK: INCORRECT TIME FIELD
                 if (is_numeric($curr_field) == true)
                     $errors[] = $line;//$curr_field;
                 else
                 {
                     $current_time->start = $curr_field;
                     //ERROR CHECK: DUPLICATE FIELDS
                     if (in_array($current_time,$times))
                         $errors[] = $line;
                     else
                         $times[] = clone $current_time;  
                 }
                 $this->Skip_Whitespace($cursor, $curr_line);
             }
             //continue onto the next line
             $line++;
         }
         
         //ERROR CHECK: NO TIMES FOUND
         if (empty($times))
             $errors[] =$line;
         
         //return either a list of erros or a list of fields
         if (empty($errors))
             return $times;
         else
             return ($errors);  
     }
 }
?>



