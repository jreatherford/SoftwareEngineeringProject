<?php
//******************************************************************************
//    James Reatherford
//    Hongbin Yu
//******************************************************************************
//    Created on: 4/11/13
//    Last Edit on: 4/11/13
//******************************************************************************
//    Things missing in this version:
//      *does not produces real error codes
//      *Documentation needs improvement
//      *Needs to be tested to make sure it conforms to coding standards
//******************************************************************************

include_once 'Structures.php';
include_once 'Recognizers.php';
include_once 'Scanner_Helper.php';
include_once 'Conflict_Time_File_Reader.php';

class File_Reader
{
    protected $text;
    protected $data_list;
    protected $error_list;
    
    public function __construct($raw_text)
    {
         
        $raw_text = preg_replace('/\h+/', ' ', $raw_text);
        $this->text = explode("\n", $raw_text);
        $this->data_list = array();
        $this->error_list = array();
    }
    
     protected function Read_A_Line($curr_line){}
     public function Scan_File()
     {
         $line = 1;      
         foreach ($this->text as $curr_line)
         {
             $error = $this->Read_A_Line($curr_line);

             if ($error != 0)
                 $this->error_list[] = Error_Table::$list[$error] ." ($line)";

             $line++;
         }
         
         //return either a list of erros or a list of fields
         if (empty($this->error_list))
             return ($this->data_list);
         else
             return ($this->error_list);  
     } 
}


 class Times_File_Reader extends File_Reader
 {
    //**************************************************************************
    //    SCAN_FILE
    //    
    //    James Reatherford, Hongbin Yu
    //**************************************************************************
    //    This function scans through the text it was given at creation,
    //    picks apart the fields and creates a list of Time objects.
    //    
    //    The function also keeps track of all errors found while scanning.
    //    
    //    If any errors were found, the function returns a list of them.  
    //    Otherwise it returns the list of Times.
    //**************************************************************************
     private $day_pattern = array();
     
     protected function Read_A_Line($curr_line)
     {
         $cursor = 0;
         
         if (preg_match("/^\s$/",$curr_line))
             return 13;
         
         //Check duration
         $curr_field = Grab_Field($cursor, $curr_line, " ");
         $error = Integer_Recognizer::read($curr_field,0,9999999999);
         if ($error != 0)
             return $error;
         else
         {
             $curr_time = new Class_Time();
             $curr_time->duration = $curr_field;
         }
         
         //Check days
         $curr_field = Grab_Field($cursor,$curr_line,"/");
         $error = Days_Recognizer::read($curr_field);
         if ($error != 0)
            return $error;
         else
            $curr_time->days = $curr_field;
         
         //check for lines that start with the same duration/day combo
         $curr_pattern = $curr_time->duration . $curr_time->days;
         if (in_array($curr_pattern, $this->day_pattern))
             return 3;
         else
             $this->day_pattern[] = $curr_pattern;
         
         
         //skip past the /
         $cursor++;
         
         // JAMES, I THINK THE NEXT LINE OF CODE SHOULD BE 
         //if (($curr_line[$cursor] === ' ') || ($cursor >= (strlen($curr_line))))
         // BECAUSE IT SKIPPED OR LOOK AHEAD ONE MORE SPOT!
         // IF YOU CAN TEST IT WITH YOUR FILE, TRY TO COMPARE THESE
         // MWF/0    AND MWF/
         
         //check there is no whitespace after the '/' & we are not over the line
         if (($curr_line[$cursor] === ' ') || ($cursor >= (strlen($curr_line)-1)))
             return 18;
         
         while ($cursor < (strlen($curr_line)-1))
         {
             $curr_field = Grab_Field($cursor,$curr_line," ");

             $error = Time_Recognizer::read($curr_field);
             if ($error != 0)
                 return $error;
             else
             {
                 $curr_time->start = $curr_field;
                 if (in_array($curr_time, $this->data_list) == false)
                     $this->data_list[] = clone $curr_time;
                 else
                     return 3;
             }
             Skip_Whitespace($cursor,$curr_line);
         }
         return 0;
     }
 }
 
 class Room_File_Reader extends File_Reader
{
    //**************************************************************************
    //    SCAN_FILE
    //    
    //    James Reatherford, Hongbin Yu
    //**************************************************************************
    //    This function scans through the text it was given at creation,
    //    picks apart the fields and creates a list of abailable time objects.
    //    
    //    The function also keeps track of all errors found while scanning.
    //    
    //    If any errors were found, the function returns a list of them.  
    //    Otherwise it returns the list of available rooms.
    //**************************************************************************
        
     protected Function Read_A_Line($curr_line)
     {
         $current_pos = 0;
         $error_found;
         $next_token;
         $current_room = new Room();
         
         // check if it is empty line
         if (empty($curr_line) || $curr_line == ' ')//(preg_match("/^\s$/", $curr_line))
         {
             return 13;
         }
         else
         {   
             // read the room type
             if ($next_token = Grab_Field($current_pos, $curr_line, ' '))
             {
                 // room type recognizer
                 $error_found = Room_Type_Recognizer::read($next_token);
                 if ($error_found == 0)
                     $current_room->type = $next_token;
                 else
                     return $error_found;
             }
             else
                 return 19;
             
            
            // read the room size
             $next_token = Grab_Field($current_pos, $curr_line, ' ');
            if (strlen($next_token) != 0)
            {
                 // room type recognizer
                 $error_found = Integer_Recognizer::read($next_token, 0, 101);
                 if ($error_found == false)
                     $current_room->size = $next_token;
                 else
                     return $error_found;
             }
             else
                 return 15;
             
             
            // read the room 
            $error_found = Room_Recognizer::read($curr_line, $current_pos);
            if (is_numeric($error_found))
            {
                return $error_found;
            }
            else
                $current_room->name = $error_found;

            
            // check if the line contains extra data
            if (Contains_Extra_Data($current_pos, $curr_line))
                return 25;
            else
            {
                //ERROR CHECK: DUPLICATE FIELDS
                foreach ($this->data_list as $temp_token)
                {
                    if ($current_room->name == $temp_token->name)  
                        return 3;
                    
                }
                
                $this->data_list[] = clone $current_room; 
            }
            return 0;
         }   
     }
 }
 
class Conflict_File_Reader extends File_Reader
{
    //**************************************************************************
    //    SCAN_FILE
    //    
    //    James Reatherford, Hongbin Yu
    //**************************************************************************
    //    This function scans through the text it was given at creation,
    //    picks apart the fields and creates a list of abailable time objects.
    //    
    //    The function also keeps track of all errors found while scanning.
    //    
    //    If any errors were found, the function returns a list of them.  
    //    Otherwise it returns the list of available rooms.
    //**************************************************************************
        
     protected Function Read_A_Line($curr_line)
     {
         $current_pos = 0;
         $error;
         $next_token;
         $current_conflict = new Conflict_Time();
         
         // check if it is empty line
         if (empty($curr_line) || $curr_line == " ")//if (preg_match("/^\s$/", $curr_line))
             return 13;
         else
         {
            // read the course name
            $error = Course_Recognizer::read($curr_line, $current_pos);
            if (is_numeric($error))
                return $error;
            else
                $current_conflict->course_name = $error;

            // loop to read conflict times till EOL
            while($current_pos < strlen($curr_line))
            {
                $next_token = Grab_Field($current_pos, $curr_line, "/");
                $error = Days_Recognizer::read($next_token);
                if ($error != 0)
                    return $error;
                else
                    $current_conflict->days = $next_token;

                $current_pos++; 

                //check there is no whitespace after the '/' and not EOL
                if ($curr_line[$current_pos] == ' ')
                    return 26;
                if ($current_pos >= (strlen($curr_line)))
                    return 18;

                // read a time
                $next_token = Grab_Field($current_pos, $curr_line, " ");
                $error = Time_Recognizer::read($next_token);
                if ($error != 0)
                    return $error;
                else
                {
                    $current_conflict->time = $next_token;
                }

                // check if it is duplicate and store into data_list
                if (in_array($current_conflict, $this->data_list))
                    return 3;
                else
                   $this->data_list[] = clone $current_conflict;

                // check if there is more data at the rest of the line
                Skip_Whitespace($current_pos, $curr_line);
            }


            if (!isset($current_conflict->days))
                return 16;
            else
                return 0;
         }
    }   
}
 
 class Prereq_File_Reader extends File_Reader
 {
    //**************************************************************************
    //    SCAN_FILE
    //    
    //    James Reatherford, Hongbin Yu
    //**************************************************************************
    //    This function scans through the text it was given at creation,
    //    picks apart the fields and creates a list of Time objects.
    //    
    //    The function also keeps track of all errors found while scanning.
    //    
    //    If any errors were found, the function returns a list of them.  
    //    Otherwise it returns the list of Times.
    //**************************************************************************
     
     protected function Read_A_Line($curr_line)
     {
         $cursor = 0;
         $prereqs = array();
         $course;
         
         if (preg_match("/^\s$/",$curr_line))
             return 13;

         while ($cursor < (strlen($curr_line)-2))
         {
             $curr_field = Course_Recognizer::read($curr_line, $cursor);
             if (is_numeric($curr_field))
                 return $curr_field;

             if (isset($course)== false)
             {
                 $course = $curr_field; 
             }
             else
             {
                 //check for duplicate data within the line
                 if (($curr_field == $course) || (in_array($curr_field,$prereqs)))
                     return 3;
                 else
                     $prereqs[] = $curr_field;
             }
         }
         

         if (isset($course))
         {
             //check for duplicate line headers
            if (isset($this->data_list["$course"]) == TRUE)
                return 3;
            else
                $this->data_list["$course"] = $prereqs;
           return 0;
         }
         else
             return 21;
         
     }
 }
?>


