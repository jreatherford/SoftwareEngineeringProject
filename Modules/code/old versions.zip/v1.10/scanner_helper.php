<?php

// this file contains functions produce the

function Skip_Whitespace(&$current_pos, $text)
{
    //skip past whitespace at the start
    while (($current_pos < strlen($text) && ($text[$current_pos] === ' ')))
        $current_pos++;
}
    

function Grab_Field(&$current_pos, $text, $delimiter)
{
    $start_pos = $current_pos;
    
    Skip_Whitespace($current_pos, $text);
     
    //skip over the word until the next delimiter
    while (($current_pos < strlen($text) && ($text[$current_pos] != $delimiter)))
        $current_pos++;

    return trim(substr($text, $start_pos, ($current_pos - $start_pos)));
}

function Contains_Extra_Data(&$current_pos, $text)
{
    Skip_Whitespace($current_pos, $text);

    if ($current_pos >= strlen($text))
    {
        return false;
    }
    else
        return true;
}


 class error_table
{
     public static $list = array(
    1 => "Unknown file name",
    2 => "Unknown data",
    3 => "Duplicate data exist in the file",
    4 => "Data contains lowercase character(s)",
    5 => "Data does not match the [integer] format",
    6 => "Data does not match the [day] format",
    7 => "Data does not match the [time] format",
    8 => "Data does not match the [room] format",
    9 => "Data does not match the [room type] format",
    10 => "Data does not match the [course] format",
    11 => "Data does not match the [faculty name] format",
    12 => "Data does not match the [year_of_service] format",
    13 => "Input file contains empty line",
    14 => "Integer exceeds the data limitation", 
    15 => "Program expecting [integer] data",
    16 => "Program expecting [day] data",
    17 => "Program expecting [ / symbol ] data",
    18 => "Program expecting [time] data",
    19 => "Program expecting [room type] data",
    20 => "Program expecting [room] data",
    21 => "Program expecting [course] data",
    22 => "Program expecting [faculty name] data",
    23 => "Program expecting [year of service] data",
    24 => "Program expecting [email] data",
    25 => "Input file contains extra unidentified data",
    26 => "Space exists before or after [ / symbol]");
}



?>
