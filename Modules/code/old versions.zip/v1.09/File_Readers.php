<?php
//******************************************************************************
//    James Reatherford
//    Hongbin Yu
//******************************************************************************
//    Created on: 4/11/13
//    Last Edit on: 4/11/13
//******************************************************************************
//    Things missing in this version:
//      *does not produces real error codes
//      *Documentation needs improvement
//      *Needs to be tested to make sure it conforms to coding standards
//******************************************************************************

include_once 'Structures.php';
include_once 'Recognizers.php';
//include 'Room_File_Reader.php';
include_once 'Scanner_Helper.php';

class File_Reader
{
    protected $text;
    protected $data_list;
    protected $error_list;
    
    public function __construct($raw_text)
    {
         
        $raw_text = preg_replace('/\h+/', ' ', $raw_text);
        $this->text = explode("\n", $raw_text);
        $this->data_list = array();
        $this->error_list = array();
    }
    
     protected function Read_A_Line($curr_line){}
     public function Scan_File()
     {
         $line = 1;      
         foreach ($this->text as $curr_line)
         {
             $error = $this->Read_A_Line($curr_line);

             if ($error != 0)
                 $this->error_list[] = Error_Table::$list[$error] ." ($line)";

             $line++;
         }
         
         //return either a list of erros or a list of fields
         if (empty($this->error_list))
             return ($this->data_list);
         else
             return ($this->error_list);  
     }
    
     
    
}


 class Times_File_Reader extends File_Reader
 {
    //**************************************************************************
    //    SCAN_FILE
    //    
    //    James Reatherford, Hongbin Yu
    //**************************************************************************
    //    This function scans through the text it was given at creation,
    //    picks apart the fields and creates a list of Time objects.
    //    
    //    The function also keeps track of all errors found while scanning.
    //    
    //    If any errors were found, the function returns a list of them.  
    //    Otherwise it returns the list of Times.
    //**************************************************************************
     private $day_pattern = array();
     
     protected function Read_A_Line($curr_line)
     {
         $cursor = 0;
         
         if (preg_match("/^\s$/",$curr_line))
             return 13;
         
         //Check duration
         $curr_field = Grab_Field($cursor, $curr_line, " ");
         $error = Integer_Recognizer::read($curr_field,0,9999999999);
         if ($error != 0)
             return $error;
         else
         {
             $curr_time = new Class_Time();
             $curr_time->duration = $curr_field;
         }
         
         //Check days
         $curr_field = Grab_Field($cursor,$curr_line,"/");
         $error = Days_Recognizer::read($curr_field);
         if ($error != 0)
            return $error;
         else
            $curr_time->days = $curr_field;
         
         //check for lines that start with the same duration/day combo
         $curr_pattern = $curr_time->duration . $curr_time->days;
         if (in_array($curr_pattern, $this->day_pattern))
             return 3;
         else
             $this->day_pattern[] = $curr_pattern;
         
         
         //skip past the /
         $cursor++;
         
         //check there is no whitespace after the '/' & we are not over the line
         if (($curr_line[$cursor] === ' ') || ($cursor >= (strlen($curr_line)-1)))
             return 18;

         while ($cursor < (strlen($curr_line)-1))
         {
             $curr_field = Grab_Field($cursor,$curr_line," ");

             $error = Time_Recognizer::read($curr_field);
             if ($error != 0)
                 return $error;
             else
             {
                 $curr_time->start = $curr_field;
                 if (in_array($curr_time, $this->data_list) == false)
                     $this->data_list[] = clone $curr_time;
                 else
                     return 3;
             }
             Skip_Whitespace($cursor,$curr_line);
         }
         return 0;
     }
 }
 
 
  class Prereq_File_Reader extends File_Reader
 {
    //**************************************************************************
    //    SCAN_FILE
    //    
    //    James Reatherford, Hongbin Yu
    //**************************************************************************
    //    This function scans through the text it was given at creation,
    //    picks apart the fields and creates a list of Time objects.
    //    
    //    The function also keeps track of all errors found while scanning.
    //    
    //    If any errors were found, the function returns a list of them.  
    //    Otherwise it returns the list of Times.
    //**************************************************************************
     
     protected function Read_A_Line($curr_line)
     {
         $cursor = 0;
         $prereqs = array();
         $course;
         
         if (preg_match("/^\s$/",$curr_line))
             return 13;

         while ($cursor < (strlen($curr_line)-2))
         {
             $curr_field = Course_Recognizer::read($curr_line, $cursor);
             if (is_numeric($curr_field))
                 return $curr_field;

             if (isset($course) == false)
             {
                 $course = $curr_field; 
             }
             else
             {
                 //check for duplicate data within the line
                 if (($curr_field == $course) || (in_array($curr_field,$prereqs)))
                     return 3;
                 else
                     $prereqs[] = $curr_field;
             }
         }
         

         if (isset($course))
         {
             //check for duplicate line headers
            if (isset($this->data_list["$course"]) == TRUE)
                return 3;
            else
                $this->data_list["$course"] = $prereqs;
           return 0;
         }
         else
             return 21;
         
     }
 }
?>


