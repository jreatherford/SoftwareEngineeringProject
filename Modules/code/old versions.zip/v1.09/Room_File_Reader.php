<?php
//******************************************************************************
//    James Reatherford
//    Hongbin Yu
//******************************************************************************
//    Created on: 4/12/13
//    Last Edit on: 4/12/13
//******************************************************************************
//    Things missing in this version:
//      *does not produces real error codes
//      *Documentation needs improvement
//      *Needs to be tested to make sure it conforms to coding standards
//******************************************************************************



class Room_File_Reader extends File_Reader
{
    //**************************************************************************
    //    SCAN_FILE
    //    
    //    James Reatherford, Hongbin Yu
    //**************************************************************************
    //    This function scans through the text it was given at creation,
    //    picks apart the fields and creates a list of abailable time objects.
    //    
    //    The function also keeps track of all errors found while scanning.
    //    
    //    If any errors were found, the function returns a list of them.  
    //    Otherwise it returns the list of available rooms.
    //**************************************************************************
        
     protected Function Read_A_Line($curr_line)
     {
         $current_pos = 0;
         $error_found;
         $next_token;
         $current_room = new Room();
         
         // check if it is empty line
         if (empty($curr_line) || $curr_line == ' ')//(preg_match("/^\s$/", $curr_line))
         {
             return 13;
         }
         else
         {   
             // read the room type
             if ($next_token = Grab_Field($current_pos, $curr_line, ' '))
             {
                 // room type recognizer
                 $error_found = Room_Type_Recognizer::read($next_token);
                 if ($error_found == false)
                     $current_room->type = $next_token;
                 else
                     return $error_found;
             }
             else
                 return 19;
             
            
            // read the room size
             $next_token = Grab_Field($current_pos, $curr_line, ' ');
            if (strlen($next_token) != 0)
            {
                 // room type recognizer
                 $error_found = Integer_Recognizer::read($next_token, 0, 101);
                 if ($error_found == false)
                     $current_room->size = $next_token;
                 else
                     return $error_found;
             }
             else
                 return 15;
             
             
            // read the room 
            $error_found = Room_Recognizer::read($curr_line, $current_pos);
            if (is_numeric($error_found))
            {
                return $error_found;
            }
            else
                $current_room->name = $error_found;

            
            // check if the line contains extra data
            if (Contains_Extra_Data($current_pos, $curr_line))
            {
                return 25;
            }
            else
            {
                //ERROR CHECK: DUPLICATE FIELDS
                foreach ($this->data_list as $temp_token)
                {
                    if ($current_room->name == $temp_token->name)  
                        return 3;
                    
                }
                
                $this->data_list[] = clone $current_room; 
            }
            return 0;
         }   
     }
 }
?>



