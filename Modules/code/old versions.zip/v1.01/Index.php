<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
        include 'Recognizers.php';
        
        $foo = new Time_Recognizer();
        $curr_pos = 0;
        echo $foo->read("09:00", $curr_pos, 0);
        echo "<br> {$curr_pos}"
        ?>
    </body>
</html>
