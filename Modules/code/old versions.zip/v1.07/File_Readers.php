<?php
//******************************************************************************
//    James Reatherford
//    Hongbin Yu
//******************************************************************************
//    Created on: 4/11/13
//    Last Edit on: 4/11/13
//******************************************************************************
//    Things missing in this version:
//      *does not produces real error codes
//      *Documentation needs improvement
//      *Needs to be tested to make sure it conforms to coding standards
//******************************************************************************

include_once 'Structures.php';
include_once 'Recognizers.php';
//include 'Room_File_Reader.php';
include_once 'Scanner_Helper.php';

class File_Reader
{
    protected $text;
    protected $data_list;
    protected $error_list;
    
     public function __construct($raw_text)
    {
        $this->text = $raw_text;
        $this->data_list = array();
        $this->error_list = array();
    }
    
    public function Scan_File (){}
    protected function Read_A_Line($curr_line){}
    
}


 class Times_File_Reader extends File_Reader
 {
    //**************************************************************************
    //    SCAN_FILE
    //    
    //    James Reatherford, Hongbin Yu
    //**************************************************************************
    //    This function scans through the text it was given at creation,
    //    picks apart the fields and creates a list of Time objects.
    //    
    //    The function also keeps track of all errors found while scanning.
    //    
    //    If any errors were found, the function returns a list of them.  
    //    Otherwise it returns the list of Times.
    //**************************************************************************
     private $day_pattern = array();
     
     Public Function Scan_File()
     {
         
         $lines = explode("\n", $this->text);
         $curr_line;
         $error;
  
         $line = 1;      
         foreach ($lines as $curr_line)
         {
             $curr_line = preg_replace('/(?:\s\s+|\n|\t)/', ' ', $curr_line);
             if ($curr_line === " ")
                $this->error_list[] = 13;
             else
             {
                $error = $this->Read_A_Line($curr_line);
                if ($error != 0)
                    $this->error_list[] = "Error $error on line $line";
             }

             $line++;
         }
         
         //return either a list of erros or a list of fields
         if (empty($this->error_list))
             return ($this->data_list);
         else
             return ($this->error_list);  
     }
     
     protected function Read_A_Line($curr_line)
     {
         $cursor = 0;
         //Check duration
         $curr_field = Grab_Field($cursor, $curr_line, " ");
         $error = Integer_Recognizer::read($curr_field,0,1000);
         if ($error != 0)
             return $error;
         else
         {
             $curr_time = new Class_Time();
             $curr_time->duration = $curr_field;
         }
         
         //Check days
         $curr_field = Grab_Field($cursor,$curr_line,"/");
         $error = Days_Recognizer::read($curr_field);
         if ($error != 0)
            return $error;
         else
            $curr_time->days = $curr_field;
         
         //check for lines that start with the same duration/day combo
         $curr_pattern = $curr_time->duration . $curr_time->days;
         if (in_array($curr_pattern, $this->day_pattern))
            return 3;
         else
             $this->day_pattern[] = $curr_pattern;
         
         
         //skip past the /
         $cursor++;
         //check there is no whitespace after the '/' & we are not over the line
         if (($curr_line[$cursor] === ' ') || ($cursor >= strlen($curr_line)))
            return 18;

         while ($cursor < strlen($curr_line))
         {
             $curr_field = Grab_Field($cursor,$curr_line," ");

             $error = Time_Recognizer::read($curr_field);
             if ($error != 0)
                return $error;
             else
             {
                 $curr_time->start = $curr_field;
                 if (in_array($curr_time, $this->data_list) == false)
                    $this->data_list[] = clone $curr_time;
                 else
                     return 3;
             }
             Skip_Whitespace($cursor,$curr_line);
         }
         return 0;
     }
 }
?>


