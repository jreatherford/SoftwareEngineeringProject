<?php

// this file contains functions produce the

function Skip_Whitespace(&$current_pos, $text)
{
    //skip past whitespace at the start
    while (($current_pos < strlen($text) && ($text[$current_pos] === ' ')))
        $current_pos++;
}
    

function Grab_Field(&$current_pos, $text, $delimiter)
{
    $start_pos = $current_pos;
    
    Skip_Whitespace($current_pos, $text);
     
    //skip over the word until the next delimiter
    while (($current_pos < strlen($text) && ($text[$current_pos] != $delimiter)))
        $current_pos++;

    return trim(substr($text, $start_pos, ($current_pos - $start_pos)));
}


$error_table = array(
    1 => "unknown file name",
    2 => "unknown data",
    3 => "duplicate data exist in the file",
    4 => "data contains lowercase character(s)",
    5 => "data does not match the [integer] format",
    6 => "data does not match the [day] format",
    7 => "data does not match the [time] format",
    8 => "data does not match the [room] format",
    9 => "data does not match the [room type] format",
    10 => "data does not match the [course] format",
    11 => "data does not match the [faculty name] format",
    12 => "data does not match the [year_of_service] format",
    13 => "input file contains empty line",
    14 => "integer exceeds the data limitation", 
    15 => "program expecting [integer] data",
    16 => "program expecting [day] data",
    17 => "program expecting [ / symbol ] data",
    18 => "program expecting [time] data",
    19 => "program expecting [room type] data",
    20 => "program expecting [room] data",
    21 => "program expecting [course name] data",
    22 => "program expecting [faculty name] data",
    23 => "program expecting [year of service] data",
    24 => "program expecting [email] data",
    25 => "input file contains extra unidentified data", 
    
);



?>
