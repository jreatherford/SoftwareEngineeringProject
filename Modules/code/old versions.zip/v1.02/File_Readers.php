<?php
//******************************************************************************
//    James Reatherford
//    Hongbin Yu
//******************************************************************************
//    Created on: 4/11/13
//    Last Edit on: 4/11/13
//******************************************************************************
//    Things missing in this version:
//      *does not check for duplicates
//      *does not produces real error codes
//      *Has not been approved for all test files
//      *Documentation is still incomplete
//******************************************************************************

include 'Structures.php';
include 'Recognizers.php';

class File_Reader 
{
    
    protected $text;
    
     public function __construct($file_text)
    {
        $this->text = preg_replace("/\h/"," ",$file_text);
    }
    
    public function Scan_File (){}
    
    function Skip_Whitespace(&$current_pos, $text)
    {
        //skip past whitespace at the start
        while (($current_pos < strlen($text) && ($text[$current_pos] == ' ')))
            $current_pos++;
    }
    
    protected function Grab_Field(&$current_pos, $text)
    {
        $start_pos = $current_pos;
        
        //skip over the word until the next whitespace
        while (($current_pos < strlen($text) && ($text[$current_pos] != ' ')))
            $current_pos++;
        
        return trim(substr($text, $start_pos, ($current_pos - $start_pos)));
    }
    

}
 
 class Times_File_Reader extends File_Reader
 {
     Public Function Scan_File()
     {
         $errors = array();
         $times = array();
         $lines = explode("\n", $this->text);
         $curr_line;
         $current_time;
         
         $line = 0;
         foreach ($lines as $curr_line)
         {
             $cursor = 0;
             $this->Skip_Whitespace($cursor, $curr_line);
             $curr_field = $this->Grab_Field($cursor, $curr_line);

             if (is_numeric($curr_field) == false)
             {
                 //THIS NEEDS TO BE REPLACED WITH A PROPER ERROR CODE
                 $errors[] = -1;
                 break;
             }
             else
             {
                 $current_time = new Class_Time();
                 $current_time->duration = $curr_field;
             }

             $curr_field = Days_Recognizer::read($curr_line,$cursor,$line);
             if (is_numeric($curr_field) == true)
             {
                 $errors[] = $curr_field;
                 break;
             }
             else
             {
                 $current_time->days = $curr_field;
             }

             $this->Skip_Whitespace($cursor, $curr_line);
            while ($cursor <= (strlen($curr_line)-4))
             {
                 $curr_field = Time_Recognizer::read($curr_line,$cursor,$line);
                 if (is_numeric($curr_field) == true)
                 {
                     $errors[] = $curr_field;
                     break;
                 }
                 else
                 {
                     $current_time->start = $curr_field;
                     $times[] = clone $current_time;
                     
                 }
                 $this->Skip_Whitespace($cursor, $curr_line);
             }
             $line++;
         }
         
         if (empty($times))
             $errors[] = -1;

         if (empty($errors))
             return $times;
         else
             return ($errors);
             
     }
 }

?>