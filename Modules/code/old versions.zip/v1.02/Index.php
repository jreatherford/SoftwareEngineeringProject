<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <a href="testAll.php">To check all the files, click here!</a><br>
        <?php

        
       include 'File_Readers.php';
        
      $text = file_get_contents("tests\\32_CT.txt"); //45, 46
      $reader = new Times_File_Reader($text);
      $array = $reader->Scan_File();
        
      foreach ($array as &$token)
      {
          if (is_numeric($token))
          {
              echo "Error $token<br>";
          }
          else
          {
          echo "------------------------------------<br>
                Days: $token->days <br>
                Start Time: $token->start <br>
                Duration: $token->duration <br>
                ------------------------------------<br>";
          }
      }
        ?>
    </body>
</html>
