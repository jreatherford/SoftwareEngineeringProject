<?php
//******************************************************************************
//    James Reatherford
//    Hongbin Yu
//******************************************************************************
//    Created on: 4/09/13
//    Last Edit on: 4/11/13
//******************************************************************************
//    This file contains a structure for an abstract class called recognizer
//    along with four classes that derive from this class.
//    The recognizer classes simply take in a position in a line and pull a
//    field from that position.  The fields these classes look for are as
//    follows:
//       *Days
//       *Room
//       *Times
//       *Course Names
//       
// Things improved from last version:
//       *No line is longer than 80 characters
//       
// Things that still need to be improves
//       *Better documentation
//       *Needs to be checked for adherence to standards
//******************************************************************************

abstract class Recognizer 
{
    public static function read($text, &$current_pos, $line_number){}
}

class Days_Recognizer extends Recognizer
{
    public static function read($text, &$current_pos, $line_number)
    {
        $start_pos = $current_pos;
        
        //advance past the '/'
        while (($current_pos < strlen($text) && ($text[$current_pos] != '/')))
            $current_pos++;
        $current_pos++;
        
        //THIS NEEDS TO BE REPLACED WITH A PROPER ERROR CODE
        if ($current_pos > strlen($text))
            return $line_number;
        
        //get the token
        $length = (($current_pos - 1) - $start_pos);
        $token = trim(substr($text, $start_pos, $length));
        if (preg_match("/^(MT?W?R?F?)$|".
                        "^(M?TW?R?F?)$|".
                        "^(M?T?WR?F?)$|".
                        "^(M?T?W?RF?)$|".
                        "^(M?T?W?R?F)$/",$token) == 1)
            return $token;
        else 
        {
            //THIS NEEDS TO BE REPLACED WITH A PROPER ERROR CODE!!!
            return $line_number;
        }    
    }
}

class Time_Recognizer extends Recognizer
{
    public static function read($text, &$current_pos, $line_number)
    {
        $start_pos = $current_pos;
        
        //skip past whitespace at the start
        while (($current_pos < strlen($text) && ($text[$current_pos] == ' ')))
            $current_pos++;
        
        //skip over the word until the next whitespace
        while (($current_pos < strlen($text) && ($text[$current_pos] != ' ')))
            $current_pos++;
        
        //THIS NEEDS TO BE REPLACED WITH A PROPER ERROR CODE
        if ($current_pos > strlen($text))
                return $line_number;
        
        $token = trim(substr($text, $start_pos, ($current_pos - $start_pos)));
        if (preg_match("/^(([0-1][0-9])|(2[0-3])):([0-5][0-9])$/",$token) == 1)
            return $token;
        else 
        {
            //THIS NEEDS TO BE REPLACED WITH A PROPER ERROR CODE!!!
            return $line_number;
        } 
    }
}

class Room_Recognizer extends Recognizer
{
    public static function read($text, &$current_pos, $line_number)
    {
        $start_pos = $current_pos;
        
        //skip past whitespace at the start
        while (($current_pos < strlen($text) && ($text[$current_pos] == ' ')))
            $current_pos++;
        
        //skip over both words until the next whitespace
        $space_count = 0;
        while (($current_pos < strlen($text)) && ($space_count < 2))
        {
            $current_pos++;
            
            if ($current_pos >= strlen($text))
                break;
            else if ($text[$current_pos] == ' ')
                $space_count++;
        }
        
        //THIS NEEDS TO BE REPLACED WITH A PROPER ERROR CODE
        if ($current_pos > strlen($text))
                return $line_number;
        
        //get the token
        $token = trim(substr($text, $start_pos, ($current_pos - $start_pos)));
        if (preg_match("/^[A-Z]+ [1-9]([0-9]{0,3})$/",$token) == 1)
            return $token;
        else 
        {
            //THIS NEEDS TO BE REPLACED WITH A PROPER ERROR CODE!!!
            return -$line_number;
        } 
    }
}

class Course_Recognizer extends Recognizer
{
    public static function read($text, &$current_pos, $line_number)
    {
        $start_pos = $current_pos;
        
        //skip past whitespace at the start
        while (($current_pos < strlen($text) && ($text[$current_pos] == ' ')))
            $current_pos++;
        
        /* 5 characters is the minimum possible size of a class field
         * There is an optional space allowed in the field that will
         * occour between the 2nd and 5th space in the field.
         * Therefore, immediatly advancing the cursor 6 spaces past the spot
         * will gaurentee that the optional space is grabbed without goint
         * into the next field
         */
        if ((strlen($text) - $current_pos) == 5)
            $current_pos += 5;
        else
            $current_pos += 6;
        
        //skip over the rest of the word until the next whitespace
        while (($current_pos < strlen($text) && ($text[$current_pos] != ' ')))
            $current_pos++;
        
        //THIS NEEDS TO BE REPLACED WITH A PROPER ERROR CODE
        if ($current_pos > strlen($text))
                return $line_number;
        
        //get the token
        $token = trim(substr($text, $start_pos, ($current_pos - $start_pos)));
        $regex = "/^[A-Z]{2,4} ?([1-4][0-9][0-9])|(099)[A-Z]?$/";
        if (preg_match($regex,$token) == 1)
            return $token;
        else 
        {
            //THIS NEEDS TO BE REPLACED WITH A PROPER ERROR CODE!!!
            return -$line_number;
        } 
    }
}
?>
