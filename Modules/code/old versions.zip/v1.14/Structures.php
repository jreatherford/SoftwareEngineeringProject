<?php

//******************************************************************************
//    James Reatherford
//    Hongbin Yu
//******************************************************************************
//    Created on: 4/11/13
//    Last Edit on: 4/11/13
//******************************************************************************
//    This file contains a set of classes that will be used by the file input
//    modules as well as the schedueling algorithm.
//******************************************************************************
class File_Info
{
    public $class_times = array();
    public $available_rooms = array();
    public $course_list = array();
    public $conflict_times = array();
    public $prereq_list = array();
}

class Class_Time
{
    public $days;
    public $start;
    public $duration;   
}

class Room
{
    public $name;
    public $size;
    public $type;
}

class Course
{
    public $name;
    // section is limited to one of (day, night, internet)
    public $section;
    public $type; 
    public $hours;
}

class Conflict_Time
{
    public $course_name;
    public $days;
    public $time;
}

class Faculty
{
    public $email;
    public $name;
    public $year_of_service;
    public $hour;
}

class Pref
{
    public $instructor;
    public $course_name;
    public $time_pref;
}