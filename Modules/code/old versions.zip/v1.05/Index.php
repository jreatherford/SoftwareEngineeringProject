<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <a href="testAll.php">To check all the files, click here!</a><br>
        <?php
        include 'File_Readers.php';

        $file_to_check = "test.txt";
  
      //$text = file_get_contents("tests//".$file_to_check);
      //$this->text = preg_replace("/\h/"," ",$file_text);
      //$reader = new Room_File_Reader($text);
      //$array = $reader->Scan_File();
      
      //$reader = new Room_File_Reader($file_to_check); 
      //$array = $reader->Scan_File();
      
      echo "<h3>Checking $file_to_check:</h3><br>";
      
      
      if ($text = file_get_contents("tests//".$file_to_check))
      {
         // $text = preg_replace('/[ ]{2,}|[\t]/', ' ', trim($text));
          $reader = new Room_File_Reader($text);
          $array = $reader->Scan_File();
      }
      else
          echo "FUCK YOU PHP <br>";
      
      
      foreach ($array as $token)
      {
          
          echo "------------------------------------<br>
                Name: $token->name <br>
                Size: $token->size <br>
                Type: $token->type <br>
                ------------------------------------<br>";
      }
      
      
        ?>
    </body>
</html>
