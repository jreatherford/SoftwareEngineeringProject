<?php
//******************************************************************************
//    James Reatherford
//    Hongbin Yu
//******************************************************************************
//    Created on: 4/12/13
//    Last Edit on: 4/12/13
//******************************************************************************
//    Things missing in this version:
//      *does not produces real error codes
//      *Documentation needs improvement
//      *Needs to be tested to make sure it conforms to coding standards
//******************************************************************************



 class Room_File_Reader extends File_Reader
 {
    //**************************************************************************
    //    SCAN_FILE
    //    
    //    James Reatherford, Hongbin Yu
    //**************************************************************************
    //    This function scans through the text it was given at creation,
    //    picks apart the fields and creates a list of abailable time objects.
    //    
    //    The function also keeps track of all errors found while scanning.
    //    
    //    If any errors were found, the function returns a list of them.  
    //    Otherwise it returns the list of available rooms.
    //**************************************************************************
     
     
     
    public Function Scan_File()
     {
         $line_number = 1;
         $lines = explode("\n", $this->text);
         
         foreach ($lines as $curr_line)
         {
             $curr_line = preg_replace('/(?:\s\s+|\n|\t)/', ' ', $curr_line);
             $this->Read_A_Line($curr_line, $line_number);
             $line_number++;
         }
         
         if (empty($this->error_list)){
             return $this->data_list;
         }
         else
             return $this->error_list;
     }
     
     
     private Function Read_A_Line($curr_line, $line_number)
     {
         $current_pos = 0;
         $error_found;
         $next_token;
         $current_room = new Room();
         
         // check if it is empty line
         //if (empty($curr_line))
         if (empty($curr_line) || $curr_line == " ")
         {
             $this->error_list[] = "$error_table[13] at line $line_number<br>";
         }
         else
         {   
             // read the room type
             if ($next_token = $this->Grab_Field($current_pos, $curr_line, " "))
             {
                 // room type recognizer
                 $error_found = Room_Type_Recognizer::read($next_token);
                 if ($error_found == false)
                     $current_room->type = $next_token;
                 else
                     $this->error_list[] = "$error_table[$error_found] at line $line_number<br>";
             }
             else
                 $this->error_list[] = "$error_table[19] at line $line_number<br>";
             
            
            // read the room size
            if ($next_token = $this->Grab_Field($current_pos, $curr_line, " "))
            {
                 // room type recognizer
                 $error_found = Integer_Recognizer::read($next_token, 0, 101);
                 if ($error_found == false)
                     $current_room->size = $next_token;
                 else
                     $this->error_list[] = "$error_table[$error_found] at line $line_number<br>";
             }
             else
                 $this->error_list[] = "$error_table[15] at line $line_number<br>";
             
             
            // read the room 
            $error_found = Room_Recognizer::read($curr_line, $current_pos);
            if (ctype_digit($error_found))
            {
                $this->error_list[] = "$error_table[$error_found] at line $line_number<br>";
            }
            else
                $current_room->name = $error_found;
            
            //ERROR CHECK: DUPLICATE FIELDS
            
            $this->data_list[] = clone $current_room; 
            
            /*
            // check if there is any extra data in the line
            if ($curr_pos < strlen($curr_line))
            {
                $next_token = trim(substr($curr_line, $current_pos));
                
                // line contains extra data
                if (!empty($next_token) && $next_token != " ")
                    $this->error_list[] = "$error_table[25] at line $line_number<br>";
            }
            else
            {
            
                //ERROR CHECK: DUPLICATE FIELDS
                if (in_array($current_room,$this->data_list))
                    $this->error_list[] = "$error_table[3] at line $line_number<br>";
                else
                    $this->data_list[] = clone $current_room; 
            }*/
         }
            
     }
 }
?>



