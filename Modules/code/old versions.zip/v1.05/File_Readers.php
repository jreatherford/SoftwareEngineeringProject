<?php
//******************************************************************************
//    James Reatherford
//    Hongbin Yu
//******************************************************************************
//    Created on: 4/11/13
//    Last Edit on: 4/11/13
//******************************************************************************
//    Things missing in this version:
//      *does not produces real error codes
//      *Documentation needs improvement
//      *Needs to be tested to make sure it conforms to coding standards
//******************************************************************************

include 'Structures.php';
include 'Recognizers.php';
include 'Room_File_Reader.php';
include 'Scanner_Helper.php';

class File_Reader
{
    protected $text;
    protected $data_list;
    protected $error_list;
    
     public function __construct($raw_text)
    {
        $this->text = $raw_text;
        $data_list = array();
        $error_list = array();
    }
    
    public function Scan_File (){}
    private function Read_A_Line(){}
    
    function Skip_Whitespace(&$current_pos, $buffer)
    {
        //skip past whitespace at the start
        while ($current_pos < strlen($buffer) && ($buffer[$current_pos] == ' '))
            $current_pos++;
    }
    
    protected function Grab_Field(&$current_pos, $buffer, $delimiter)
    {   
        $this->Skip_Whitespace($current_pos, $buffer);
        $start_pos = $current_pos;
        
        //skip over the word until the next whitespace
        while ($current_pos < strlen($buffer) && $buffer[$current_pos] != $delimiter)
            $current_pos++;
        
        // no token can be read
        if ($current_pos == $start_pos){
            return false;
        }
        // return token to be validated
        else{
            return trim(substr($buffer, $start_pos, ($current_pos - $start_pos)));
        }
    }
}


class File_Reader1 
{
    
    protected $text;
    
     public function __construct($file_text)
    {
        //$this->text = preg_replace("/\h/"," ",$file_text);
    }
    
    public function Scan_File (){}
    
    function Skip_Whitespace(&$current_pos, $text)
    {
        //skip past whitespace at the start
        while (($current_pos < strlen($text) && ($text[$current_pos] == ' ')))
            $current_pos++;
    }
    
    protected function Grab_Field(&$current_pos, $text)
    {
        $start_pos = $current_pos;
        
        //skip over the word until the next whitespace
        while (($current_pos < strlen($text) && ($text[$current_pos] != ' ')))
            $current_pos++;
        
        return trim(substr($text, $start_pos, ($current_pos - $start_pos)));
    }
    

}

 class Times_File_Reader extends File_Reader
 {
    //**************************************************************************
    //    SCAN_FILE
    //    
    //    James Reatherford, Hongbin Yu
    //**************************************************************************
    //    This function scans through the text it was given at creation,
    //    picks apart the fields and creates a list of Time objects.
    //    
    //    The function also keeps track of all errors found while scanning.
    //    
    //    If any errors were found, the function returns a list of them.  
    //    Otherwise it returns the list of Times.
    //**************************************************************************
     Public Function Scan_File()
     {
         $errors = array();
         $times = array();
         $day_time_patterns = array();
         $lines = explode("\n", $this->text);
         $curr_line;
         $curr_field;
         $current_time;
         $line = 1;
         
         foreach ($lines as $curr_line)
         {
             $cursor = 0;
             
             //get duration field
             $this->Skip_Whitespace($cursor, $curr_line);
             $curr_field = $this->Grab_Field($cursor, $curr_line); ///make sure does not inlcude - and decimal numbers
             //ERROR CHECK: MISSING OR INCORRECT DURATION FIELD
             if (is_numeric($curr_field) == false)
                 $errors[] = $line;
             else
             {
                 $current_time = new Class_Time();
                 $current_time->duration = $curr_field;
             }
             
             //get days field
             $curr_field = Days_Recognizer::read($curr_line,$cursor,$line);
             //ERROR CHECK: MISSING OR INCORRECT DURATION FIELD
             if (is_numeric($curr_field) == true)
                 $errors[] = $line;//$curr_field;
             else
             {
                 $current_time->days = $curr_field;
                 $curr_pattern = "$current_time->duration $current_time->days";
                 //ERROR CHECK: DUPLICATE DAY/TIME COMBINATIONS
                 if (in_array($curr_pattern,$day_time_patterns))
                     $errors[] = $line;
                 //ERROR CHECK: WHITESPACE AFTER THE DAYS FIELD
                 else if ($curr_line[$cursor] == " ")
                     $errors[] = $line;
                 else
                     $day_time_patterns[] = $curr_pattern;
             }

             //get start times
            //ERROR CHECK: NO TIMES LISTED ON LINE
            if ($cursor > (strlen($curr_line)-4))
                $errors[] = $line;
            while ($cursor <= (strlen($curr_line)-4))
            {
                 $curr_field = Time_Recognizer::read($curr_line,$cursor,$line);
                 //ERROR CHECK: INCORRECT TIME FIELD
                 if (is_numeric($curr_field) == true)
                     $errors[] = $line;//$curr_field;
                 else
                 {
                     $current_time->start = $curr_field;
                     //ERROR CHECK: DUPLICATE FIELDS
                     if (in_array($current_time,$times))
                         $errors[] = $line;
                     else
                         $times[] = clone $current_time;  
                 }
                 $this->Skip_Whitespace($cursor, $curr_line);
             }
             //continue onto the next line
             $line++;
         }
         
         //ERROR CHECK: NO TIMES FOUND
         if (empty($times))
             $errors[] =$line;
         
         //return either a list of erros or a list of fields
         if (empty($errors))
             return $times;
         else
             return ($errors);  
     }
 }
?>


