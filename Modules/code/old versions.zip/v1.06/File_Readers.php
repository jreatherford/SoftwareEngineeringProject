<?php
//******************************************************************************
//    James Reatherford
//    Hongbin Yu
//******************************************************************************
//    Created on: 4/11/13
//    Last Edit on: 4/11/13
//******************************************************************************
//    Things missing in this version:
//      *does not produces real error codes
//      *Documentation needs improvement
//      *Needs to be tested to make sure it conforms to coding standards
//******************************************************************************

include_once 'Structures.php';
include_once 'Recognizers.php';
//include 'Room_File_Reader.php';
include_once 'Scanner_Helper.php';

class File_Reader
{
    protected $text;
    protected $data_list;
    protected $error_list;
    
     public function __construct($raw_text)
    {
        $this->text = $raw_text;
        $data_list = array();
        $error_list = array();
    }
    
    public function Scan_File (){}
    private function Read_A_Line($line){}
    
}


 class Times_File_Reader extends File_Reader
 {
    //**************************************************************************
    //    SCAN_FILE
    //    
    //    James Reatherford, Hongbin Yu
    //**************************************************************************
    //    This function scans through the text it was given at creation,
    //    picks apart the fields and creates a list of Time objects.
    //    
    //    The function also keeps track of all errors found while scanning.
    //    
    //    If any errors were found, the function returns a list of them.  
    //    Otherwise it returns the list of Times.
    //**************************************************************************
     Public Function Scan_File()
     {

         $lines = explode("\n", $this->text);
         $curr_line;
         $error;
  
         $line = 1;      
         foreach ($lines as $curr_line)
         {
             echo "$curr_line<br>";
             $curr_line = preg_replace('/(?:\s\s+|\n|\t)/', ' ', $curr_line);
             
             if ($curr_line === " ")
                $error_list[] = 13;
             else
             {
                $error = $this->Read_A_Line($line);
                if ($error != 0)
                    $error_list[] = $error;
             }

             $line++;
         }
         
         //return either a list of erros or a list of fields
         if (empty($error_list))
             return $this->data_list;
         else
             return ($this->error_list);  
     }
     
     private function Read_A_Line($line)
     {
         $cursor = 0;
         $error;
         $curr_field;
         
         //Check duration
         $curr_field = Grab_Field($cursor, $line, " ");
         $error = Integer_Recognizer::read($curr_field,0,1000);
         if ($error != 0)
             return $error;
         else
         {
             $curr_time = new Class_Time();
             $curr_time->duration = $curr_field;
         }
         
         //Check days
             $curr_field = Grab_Field($cursor,$line," ");
             $error = Days_Recognizer::read($curr_field);
         if (is_numeric($curr_field))
             return $curr_field;
         else
             $curr_time->days = $curr_field;
         
         //Check times
         while ($cursor < strlen($line))
         {
             $curr_field = Grab_Field($cursor,$line," ");
             $error = Time_Recognizer::read($curr_field);
             if ($error != 0)
                 return $error;
             else
             {
                 $curr_time->time = $curr_field;
                 $this->data_list[] = clone curr_time;
             }
         }
         return 0;
         
     }
 }
?>


