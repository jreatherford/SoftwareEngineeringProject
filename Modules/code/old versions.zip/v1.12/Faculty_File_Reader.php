<?php

class Faculty_File_Reader extends File_Reader
{
    //**************************************************************************
    //    SCAN_FILE
    //    
    //    James Reatherford, Hongbin Yu
    //**************************************************************************
    //    This function scans through the text it was given at creation,
    //    picks apart the fields and creates a list of abailable time objects.
    //    
    //    The function also keeps track of all errors found while scanning.
    //    
    //    If any errors were found, the function returns a list of them.  
    //    Otherwise it returns the list of available rooms.
    //**************************************************************************
        
     protected Function Read_A_Line($curr_line)
     {
         $current_pos = 0;
         $error;
         $next_token;
         $current_faculty = new Faculty();
         
         // check if it is empty line
         if (empty($curr_line) || $curr_line == ' ')//(preg_match("/^\s$/", $curr_line))
         {
             return 13;
         }
         else
         {   
             // read the faculty name
             $error = Faculty_Name_Recognizer::read($curr_line, $current_pos);
             if (is_numeric($error))
                 return $error;
             else
                 $current_faculty->name = $error;
             
             // read the year of service
             $next_token = Grab_Field($current_pos, $curr_line, " ");
             $error = Year_Of_Service_Recognizer::read($next_token);
             
             if ($error != 0)
                 return $error;
             else
                 $current_faculty->year_of_service = $next_token;
             
             // read the faculty email
             $next_token = Grab_Field($current_pos, $curr_line, " ");
             if (strlen($next_token) == 0)
                 return 24;
             else
                 $current_faculty->email = $next_token;
             
             // read the faculty teaching hours
             $next_token = Grab_Field($current_pos, $curr_line, " ");
             $error = Integer_Recognizer::read($next_token, 0, 19);
             if ($error != 0)
                 return $error;
             else
                 $current_faculty->hour = $next_token;
             
             // check if the line contains extra data
            if (Contains_Extra_Data($current_pos, $curr_line))
                return 25;
            else
            {
                //ERROR CHECK: DUPLICATE FIELDS
                foreach ($this->data_list as $next_token)
                {
                    if ($current_faculty->email == $next_token->email)  
                        return 3;
                }
                
                $this->data_list[] = clone $current_faculty; 
            }
            return 0;
         }   
     }
 }
?>
