<?php
//******************************************************************************
//    James Reatherford
//    Hongbin Yu
//******************************************************************************
//    Created on: 4/09/13
//    Last Edit on: 4/14/13
//******************************************************************************
//    This file contains a structure for an abstract class called recognizer
//    along with four classes that derive from this class.
//    The recognizer classes simply take in a position in a line and pull a
//    field from that position.  The fields these classes look for are as
//    follows:
//       *Days
//       *Room
//       *Times
//       *Course Names
//       *Interger
//       *Room Type
//       *Name
//       
// Things improved from last version:
//       *Refactored the whole thing.  Made everything much more efficeient.
//       *Added new recognizers
//       
// Things that still need to be improves
//       *Better documentation
//       *Needs to be checked for adherence to standards
//       *Name recognizer not finished
//******************************************************************************

//abstract class Recognizer 
//{
//    public static function read($text, &$current_pos, $line_number){}
//}


class Days_Recognizer //extends Recognizer
{
    public static function read($token)
    {
        if (preg_match("#^(MT?W?R?F?)$|".
                        "^(M?TW?R?F?)$|".
                        "^(M?T?WR?F?)$|".
                        "^(M?T?W?RF?)$|".
                        "^(M?T?W?R?F)$#",$token) == 1)
            return 0;
        else 
            return 6;  
    }
}

class Time_Recognizer //extends Recognizer
{
    public static function read($token)
    {
        if (preg_match("/^(([0-1][0-9])|(2[0-3])):([0-5][0-9])$/",$token) == 1)
            return 0;
        else 
            return 7;
    }
}

class Room_Recognizer //extends Recognizer
{
    public static function read($text, &$current_pos)
    {

        //Return error if the line is empty
        if ($current_pos >= strlen($text))
            return 19;
        
        //skip over both words
        $token = Grab_Field($current_pos, $text, " ");
        $token = $token . " " . Grab_Field($current_pos, $text, " ");

        //check the format
        if (preg_match("/^[A-Z]+ [1-9]([0-9]{0,3})$/",$token) == 1)
            return 0;
        else
            return 8;

    }
}

class Course_Recognizer //extends Recognizer
{
    public static function read($text, &$current_pos)
    {
        $start_pos = $current_pos;
        
        //skip past whitespace at the start
        Skip_Whitespace($current_pos, $text);
        
        //Make sure there is something on the line
        if ($current_pos >= strlen($text))
            return 21;
        
        /* 5 characters is the minimum possible size of a class field
         * We are 1 character into the field. Any possible spaces will occour 
         * between the 2nd and 5th space in the field. Therefore, immediatly 
         * advancing the cursor 4 spaces past the spot will gaurentee that the 
         * optional space is grabbed without goint into the next field*/
        if ((strlen($text) - $current_pos) == 3)
            $current_pos += 3;
        else
            $current_pos += 4;
        
        //skip over the rest of the word until the next whitespace
        Grab_Field($current_pos, $text, " ");
        
        //get the token
        $token = trim(substr($text, $start_pos, ($current_pos - $start_pos)));

        $regex = "/^[A-Z]{2,4} ?(([1-4][0-9][0-9])|(099))[A-Z]?$/";
        if (preg_match($regex,$token) == 1)
            return preg_replace('/ /', '', $token);
        else 
            return 10;
    }
}


class Faculty_Name_Recognizer //extends Recognizer
{
    // function will return a valid name which to be stored
    // or error code if there is any
    public static function read($text, &$current_pos)
    {
        
        //skip over both words
        $token = Grab_Field($current_pos, $text, " ");
        $token = $token . " " . Grab_Field($current_pos, $text, " ");

        //check the format
        if (preg_match("/^(.+), (.+)$/",$token) == 1)
            return $token;
        else
            return 22;
    }
}


class Room_Type_Recognizer //extends Recognizer
{
    // funtion will check if the passing in $token is valid or not
    public static function read($token)
    {
        // if it contains lowercase symbol, return error code
        if (ctype_lower($token))
            return 4;
        
        // if contains more than 1 letter, return error code
        else if (strlen($token) != 1)
            return 9;
        
        // if it mataches L or C, return false indicates it is a valid token
        else if (preg_match("/^L|C$/", $token))
            return false;
        
        // if none of above matches, consider it as unknow data
        else
            return 2;
    }
}


class Integer_Recognizer //extends Recognizer
{
    // funtion will check if the passing in $token is valid or not
    public static function read($token, $min, $max)
    {
        // if it is not digit, return error code
        if (!ctype_digit($token))
            return 5;
        
        // if it is in the room size limit which is 1 to 100, includsive
        // else if ($token > $min && $token < $max)
        else if ($token >= $min && $token <= $max)
            return 0; 
       
        // integer exceeds the room size limit
        else
            return 14;
    }
}
?>
