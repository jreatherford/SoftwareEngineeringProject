<script type="text/javascript">
    alert("Redirect.");
    location = "account_management.php";
</script>
<a href="account_management.php">Account Management</a>